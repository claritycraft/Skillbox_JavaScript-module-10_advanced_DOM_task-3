let prices = [100, 500, 250, 750, 300];

function displayPrices() {
  const list = document.getElementById("price-list");
  list.innerHTML = "";
  prices.forEach((price) => {
    const li = document.createElement("li");
    li.textContent = price;
    list.appendChild(li);
  });
}

function sortPrices(order) {
  prices.sort((a, b) => (order === "asc" ? a - b : b - a));
  displayPrices();
}

displayPrices();
