const buttonSortUp = document.querySelector(".buttonUp");
const buttonSortDown = document.querySelector(".buttonDown");

const prices = ["100", "150", "600", "500", "750"];

function showPrices(array) {
  const priceList = document.getElementById("list");
  priceList.innerHTML = "";

  for (let i = 0; i < array.length; i++) {
    const li = document.createElement("li");
    li.textContent = array[i];
    priceList.appendChild(li);
  }
}

// Сортировка по возрастанию
function sortUp() {
  prices.sort(function (a, b) {
    return a - b;
  });
  showPrices(prices);
}

// Сортировка по убыванию
function sortDown() {
  prices.sort(function (a, b) {
    return b - a;
  });
  showPrices(prices);
}

// Обработчики событий
document.getElementById("sort-up").addEventListener("click", sortUp);
document.getElementById("sort-down").addEventListener("click", sortDown);

showPrices(prices);
