const buttonSortUp = document.querySelector(".buttonUp");
const buttonSortDown = document.querySelector(".buttonDown");

const prices = ["100", "150", "600", "500", "750"];

function showPrices(array) {
  const priceList = document.getElementById("list");
  priceList.innerHTML = "";

  for (let i = 0; i < array.length; i++) {
    const li = document.createElement("li");
    li.textContent = array[i];
    priceList.appendChild(li);
  }
}

// сортировка по убыванию
function sortDownManual() {
  for (let i = 0; i < prices.length; i++) {
    for (let j = 0; j < prices.length - 1; j++) {
      if (prices[j] < prices[j + 1]) {
        let temp = prices[j];
        prices[j] = prices[j + 1];
        prices[j + 1] = temp;
      }
    }
  }
  showPrices(prices);
}

// сортировка по возрастанию
function sortUpManual() {
  for (let i = 0; i < prices.length; i++) {
    for (let j = 0; j < prices.length - 1; j++) {
      if (Number(prices[j]) > Number(prices[j + 1])) {
        // меняем местами
        let temp = prices[j];
        prices[j] = prices[j + 1];
        prices[j + 1] = temp;
      }
    }
  }
  showPrices(prices);
}

buttonSortDown.addEventListener("click", sortDownManual);
buttonSortUp.addEventListener("click", sortUpManual);
showPrices(prices);
